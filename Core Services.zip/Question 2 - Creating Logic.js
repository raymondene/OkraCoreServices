//company ID: 484929849
//customer ID: 573839293

function refundCustomer(company, user, amount) {
    console.log('Hello, World');
  }
  
refundCustomer('484929849', '573839293', 2003.0)